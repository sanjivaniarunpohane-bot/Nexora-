# N.A.P AI MAX 2.0 — Android-friendly starter

Created by Nirmit Pohane. Website + installable Android PWA + secure server-side AI backend.

## What this version includes
- Five modes: AI Chat, Web Research, Learning Coach, Code Assistant, File & Image Analysis.
- Real AI calls through the OpenAI Responses API.
- Web search tool in Research mode with source links extracted from response annotations.
- Image and PDF attachments (up to 5 MB).
- Local device chat history, voice dictation when browser supports it, responsive design, PWA install support.
- API key remains in a Cloudflare Worker Secret, never in public website code.

## Important limitations
- This is an MVP, not a ChatGPT/Gemini replacement and not trained from scratch.
- Chat history is stored in this browser only; there is no account sync or cloud memory.
- Voice is browser speech-to-text only; spoken AI replies are not included yet.
- File attachment support in this version is PDF and common image types only.
- Research citations depend on the provider's returned annotations.
- No autonomous actions are enabled. Add tools only with explicit user approval and strict permissions.
- API usage may cost money. An adult/parent or guardian must own/supervise the provider account, API key, and billing. Never paste a secret key into this project, GitHub, or chat.

## 1. Publish the backend
An adult account owner should:
1. Sign in to Cloudflare and create a Worker named `nap-ai-max-api`.
2. Paste the complete contents of `worker/index.js` into the Worker editor and deploy.
3. In Worker Settings → Variables and Secrets, add `OPENAI_API_KEY` as a **Secret**. Do not add it as a plain text variable.
4. Add `OPENAI_MODEL` as a text variable set to a model enabled for the API project. The starter default is `gpt-6-astra`; change it if that model is not available to the account.
5. Set `ALLOWED_ORIGIN` to the exact website origin after the website is live. For a GitHub Pages project site, this is usually `https://USERNAME.github.io` (origin only; no `/repository-name` path).
6. Deploy the Worker again and copy its `workers.dev` URL.

Cloudflare secrets guide: https://developers.cloudflare.com/workers/configuration/secrets/

## 2. Publish the website with GitHub Pages
1. Create a GitHub repository named `nap-ai-max`.
2. Upload the contents of this project folder to the repository root. Keep the `worker` folder in the repository for your own reference.
3. Open Settings → Pages. Choose Deploy from a branch, select `main` and `/(root)`, then Save.
4. Wait for the GitHub Pages URL, usually `https://USERNAME.github.io/nap-ai-max/`.
5. In Cloudflare, set `ALLOWED_ORIGIN` to `https://USERNAME.github.io` and redeploy.

GitHub Pages guide: https://docs.github.com/pages

## 3. Connect website to backend
1. In GitHub, open `app.js` and tap Edit.
2. Replace `https://YOUR-WORKER-NAME.YOUR-SUBDOMAIN.workers.dev` in `API_URL` with the actual Worker URL.
3. Commit the change and wait for Pages to publish.
4. Open the website and test AI Chat and Web Research.

## 4. Install on Android
1. Open the published HTTPS website in Chrome.
2. Tap ⋮ → Install app or Add to Home screen.
3. Confirm. It opens in an app-like window.
This is the PWA Android version. A Play Store AAB is a separate later project.

## 5. Test checklist
- AI Chat answers a simple question.
- Research mode returns an answer and clickable sources for a current topic.
- Learning mode explains a concept clearly.
- Code mode explains a small beginner code example.
- Attach a non-private sample PDF or image in Analysis mode.
- Check that a deliberately invalid API key produces an error, not a leaked secret.
- Test on mobile data and Wi-Fi.
- Clear local history and confirm it disappears.

## 6. Before public launch
- Adult owner sets API usage budgets/alerts and monitors usage.
- Add rate limiting and per-user quotas at the backend before sharing widely.
- Add a privacy policy, contact/support details, account system, and data deletion process before collecting user accounts.
- Restrict allowed origin to your real website. Avoid `*` for public deployment.
- Do not upload private, school, family, or identity documents.
- Review all provider terms, age requirements, and applicable laws with a parent/guardian.

## Troubleshooting
- “Connect your secure AI backend”: replace API_URL in `app.js`.
- “key has not been configured”: add the Worker Secret `OPENAI_API_KEY`.
- CORS/website origin error: set `ALLOWED_ORIGIN` to the website origin and redeploy.
- Model unavailable: set `OPENAI_MODEL` to a model enabled for the API project.
- File error: use a PDF or PNG/JPEG/WEBP/GIF image smaller than 5 MB.
