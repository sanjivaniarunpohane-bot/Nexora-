// Replace this with your deployed Cloudflare Worker URL.
const API_URL = "https://YOUR-WORKER-NAME.YOUR-SUBDOMAIN.workers.dev";
const $ = id => document.getElementById(id);
const modes = {chat:"AI Chat",research:"Web Research",learn:"Learning Coach",code:"Code Assistant",analyze:"File & Image Analysis"};
let conversations = JSON.parse(localStorage.getItem("napmax_chats") || "[]");
let activeId = null, activeMode = "chat", selectedFile = null, busy = false, installEvent = null;

function save(){localStorage.setItem("napmax_chats",JSON.stringify(conversations));drawHistory()}
function current(){return conversations.find(c=>c.id===activeId)}
function newConversation(){activeId=crypto.randomUUID();conversations.unshift({id:activeId,title:"New conversation",mode:activeMode,messages:[]});save();drawMessages()}
function drawHistory(){const host=$("historyList");host.innerHTML="";conversations.forEach(c=>{const b=document.createElement("button");b.textContent=c.title;b.className=c.id===activeId?"active":"";b.onclick=()=>{activeId=c.id;activeMode=c.mode||"chat";setMode(activeMode);drawHistory();drawMessages();$("sidebar").classList.remove("open")};host.append(b)})}
function setMode(mode){activeMode=mode;$("modeTitle").textContent=modes[mode]||modes.chat;document.querySelectorAll(".mode").forEach(b=>b.classList.toggle("active",b.dataset.mode===mode));if(current())current().mode=mode}
function addMessage(role,text,sources=[]){const row=document.createElement("div");row.className="message "+role;const av=document.createElement("div");av.className="avatar";av.textContent=role==="user"?"Y":"N";const bubble=document.createElement("div");bubble.className="bubble";bubble.textContent=text;row.append(av,bubble);if(sources.length){const box=document.createElement("div");box.className="sources";box.textContent="Sources";sources.forEach(s=>{const a=document.createElement("a");a.href=s.url;a.target="_blank";a.rel="noopener noreferrer";a.textContent=s.title||s.url;box.append(a)});bubble.append(box)}$("messages").append(row);return bubble}
function drawMessages(){const c=current();$("messages").innerHTML="";$("welcome").hidden=!!(c&&c.messages.length);if(c){setMode(c.mode||"chat");c.messages.forEach(m=>addMessage(m.role,m.content,m.sources||[]))}$("content").scrollTop=$("content").scrollHeight}
function toast(msg){const t=$("toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2600)}
function renderFile(){const host=$("filePreview");host.innerHTML="";if(selectedFile){const chip=document.createElement("span");chip.className="file-chip";chip.textContent=selectedFile.name;const x=document.createElement("button");x.textContent="×";x.onclick=()=>{selectedFile=null;$("fileInput").value="";renderFile()};chip.append(x);host.append(chip)}}
function readBase64(file){return new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(String(r.result).split(",")[1]);r.onerror=reject;r.readAsDataURL(file)})}
async function send(){
 let text=$("prompt").value.trim();if(!text&&!selectedFile)return;if(busy)return;
 if(API_URL.includes("YOUR-WORKER-NAME")){toast("First connect your secure AI backend in app.js.");return}
 if(!activeId)newConversation();const c=current();const userText=text||(selectedFile?"Please analyze the attached file.":"");
 c.messages.push({role:"user",content:userText});if(c.messages.length===1)c.title=userText.slice(0,34)+(userText.length>34?"…":"");
 const file=selectedFile;$("prompt").value="";$("prompt").style.height="auto";selectedFile=null;renderFile();$("welcome").hidden=true;addMessage("user",userText+(file?"\n[Attachment: "+file.name+"]":""));
 const bubble=addMessage("assistant","N.A.P AI MAX is thinking…");bubble.classList.add("typing");busy=true;$("sendBtn").disabled=true;
 try{
  let attachment=null;
  if(file){if(file.size>5*1024*1024)throw new Error("Please attach a file smaller than 5 MB.");attachment={name:file.name,type:file.type,data:await readBase64(file)}}
  const response=await fetch(API_URL,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({mode:activeMode,messages:c.messages.slice(-12),attachment})});
  const data=await response.json();if(!response.ok)throw new Error(data.error||"AI service error");
  const answer=String(data.reply||"No answer returned.");bubble.textContent=answer;bubble.classList.remove("typing");
  const sources=Array.isArray(data.sources)?data.sources:[];if(sources.length){const box=document.createElement("div");box.className="sources";box.textContent="Sources";sources.forEach(s=>{const a=document.createElement("a");a.href=s.url;a.target="_blank";a.rel="noopener noreferrer";a.textContent=s.title||s.url;box.append(a)});bubble.append(box)}
  c.messages.push({role:"assistant",content:answer,sources});save();
 }catch(err){bubble.textContent="Sorry — "+err.message;bubble.classList.remove("typing");toast(err.message)}
 finally{busy=false;$("sendBtn").disabled=false;$("content").scrollTop=$("content").scrollHeight;save()}
}
$("sendBtn").onclick=send;$("prompt").addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();send()}});
$("prompt").addEventListener("input",()=>{$("prompt").style.height="auto";$("prompt").style.height=Math.min($("prompt").scrollHeight,140)+"px"});
$("newChat").onclick=newConversation;$("clearHistory").onclick=()=>{if(confirm("Delete all conversations saved on this device?")){conversations=[];activeId=null;save();drawMessages();toast("Device history cleared.")}};
document.querySelectorAll(".mode").forEach(b=>b.onclick=()=>{setMode(b.dataset.mode);$("sidebar").classList.remove("open");if(current())current().mode=activeMode;save()});
document.querySelectorAll(".quick").forEach(b=>b.onclick=()=>{setMode(b.dataset.mode);$("prompt").value=b.dataset.prompt;send()});
$("menuBtn").onclick=()=>$("sidebar").classList.toggle("open");
$("fileInput").onchange=e=>{const f=e.target.files[0];if(!f)return;if(!(f.type.startsWith("image/")||f.type==="application/pdf")){toast("This preview accepts images and PDF files.");return}selectedFile=f;renderFile()};
$("voiceBtn").onclick=()=>{const SR=window.SpeechRecognition||window.webkitSpeechRecognition;if(!SR){toast("Voice input is not supported in this browser.");return}const r=new SR();r.lang="en-IN";r.onresult=e=>$("prompt").value+=($("prompt").value?" ":"")+e.results[0][0].transcript;r.onerror=()=>toast("Voice input could not start.");r.start()};
window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();installEvent=e;$("installBtn").hidden=false});
$("installBtn").onclick=async()=>{if(!installEvent)return;installEvent.prompt();await installEvent.userChoice;installEvent=null;$("installBtn").hidden=true};
if("serviceWorker"in navigator)window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));
if(conversations.length){activeId=conversations[0].id;activeMode=conversations[0].mode||"chat"}drawHistory();drawMessages();
