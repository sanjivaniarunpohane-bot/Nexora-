const corsHeaders = (origin, allowed) => ({
  "Access-Control-Allow-Origin": allowed === "*" ? "*" : (origin === allowed ? origin : "null"),
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
  "Vary": "Origin"
});
function getText(response) {
  const parts = [];
  const sources = [];
  for (const item of (response.output || [])) {
    if (item.type === "message") for (const c of (item.content || [])) {
      if (c.type === "output_text" && c.text) {
        parts.push(c.text);
        for (const a of (c.annotations || [])) if (a.type === "url_citation" && a.url) sources.push({title:a.title || a.url,url:a.url});
      }
    }
  }
  return {reply:parts.join("\n\n").trim(),sources:[...new Map(sources.map(s=>[s.url,s])).values()]};
}
export default {
 async fetch(request, env) {
  const origin=request.headers.get("Origin")||"", allowed=env.ALLOWED_ORIGIN||"*";
  const headers=corsHeaders(origin,allowed);
  const json=(data,status=200)=>new Response(JSON.stringify(data),{status,headers:{...headers,"Content-Type":"application/json"}});
  if(request.method==="OPTIONS")return new Response(null,{status:204,headers});
  if(request.method!=="POST")return json({error:"Use POST."},405);
  if(allowed!=="*"&&origin!==allowed)return json({error:"This website origin is not allowed."},403);
  if(!env.OPENAI_API_KEY)return json({error:"The AI provider key has not been configured on the server."},503);
  try {
   const body=await request.json(), mode=["chat","research","learn","code","analyze"].includes(body.mode)?body.mode:"chat";
   if(!Array.isArray(body.messages)||body.messages.length<1||body.messages.length>12)return json({error:"Invalid chat history."},400);
   const input=body.messages.map(m=>{
    if(!m||!["user","assistant"].includes(m.role)||typeof m.content!=="string")throw new Error("Invalid message.");
    return {role:m.role,content:m.content.slice(0,6000)};
   });
   if(input[input.length-1].role!=="user")return json({error:"The last message must be from the user."},400);
   const system={
    chat:"You are N.A.P AI MAX, a helpful, honest, age-appropriate AI assistant created by Nirmit Pohane. Explain clearly, reason carefully, and admit uncertainty. Never claim to have performed actions you did not perform.",
    research:"You are N.A.P AI MAX Research. Research the user's question using current web sources when useful. Cite claims with links supplied by web search. Distinguish facts, estimates, and uncertainty. Do not invent sources.",
    learn:"You are N.A.P AI MAX Learning Coach. Teach step by step in simple language, use examples, check understanding, and encourage learning rather than merely giving unexplained answers. Keep content age-appropriate.",
    code:"You are N.A.P AI MAX Code Assistant. Give safe, beginner-friendly code, explain where each file goes, include setup and test steps, and never claim code was executed unless it was. Avoid insecure patterns and keep secrets server-side.",
    analyze:"You are N.A.P AI MAX Analysis. Carefully analyze the attached image or PDF when provided. Describe what is actually visible or present, distinguish observation from inference, and say if the file cannot be read."
   }[mode];
   const tools=[];
   if(mode==="research")tools.push({type:"web_search"});
   const last=input.pop();
   let lastContent=[{type:"input_text",text:last.content||"Please help with the attachment."}];
   const attachment=body.attachment;
   if(attachment){
    if(typeof attachment.data!=="string"||attachment.data.length>7_000_000)return json({error:"Attachment is too large. Use a file smaller than 5 MB."},413);
    if(attachment.type==="application/pdf"){
     lastContent.push({type:"input_file",filename:String(attachment.name||"document.pdf").slice(0,100),file_data:`data:application/pdf;base64,${attachment.data}`});
    } else if(typeof attachment.type==="string"&&attachment.type.startsWith("image/")&&["image/png","image/jpeg","image/webp","image/gif"].includes(attachment.type)){
     lastContent.push({type:"input_image",image_url:`data:${attachment.type};base64,${attachment.data}`,detail:"auto"});
    } else return json({error:"Supported attachments are PDF, PNG, JPEG, WEBP, and GIF images."},415);
   }
   input.push({role:"user",content:lastContent});
   const upstream=await fetch("https://api.openai.com/v1/responses",{
    method:"POST",
    headers:{"Authorization":`Bearer ${env.OPENAI_API_KEY}`,"Content-Type":"application/json"},
    body:JSON.stringify({model:env.OPENAI_MODEL||"gpt-6-astra",instructions:system,input,tools,store:false,max_output_tokens:1200})
   });
   const data=await upstream.json();
   if(!upstream.ok)return json({error:data.error?.message||"The AI provider returned an error. Check model access and API billing."},502);
   const result=getText(data);
   if(!result.reply)return json({error:"The AI provider returned no text. Try again."},502);
   return json(result);
  } catch(e){return json({error:e.message||"Unexpected server error."},500)}
 }
};